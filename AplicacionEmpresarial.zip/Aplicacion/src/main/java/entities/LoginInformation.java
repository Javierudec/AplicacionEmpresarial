package entities;

public class LoginInformation {
	public String username;
	public String password;
}
