package entities;

public enum Score {
	ONE, 
	TWO,
	THREE,
	FOUR,
	FIVE
}
