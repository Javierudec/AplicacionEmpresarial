package entities;

public class MovieInformation {
	public String title;
}
