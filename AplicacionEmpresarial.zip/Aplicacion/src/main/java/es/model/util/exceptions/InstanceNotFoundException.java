package es.model.util.exceptions;

public class InstanceNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

}
